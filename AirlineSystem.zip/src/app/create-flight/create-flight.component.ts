import { Component, OnInit } from "@angular/core";
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators
} from "@angular/forms";
import { AirLine } from "../airline-data";
import { DataService } from "../data.service";
import { Router } from "@angular/router";
import {providerNameValidator} from '../providername';
import {providerTypeValidator} from '../providertype';

@Component({
  selector: "app-create-flight",
  templateUrl: "./create-flight.component.html"
})
export class CreateflightComponent implements OnInit {
  isvalidDetails = true;
  providerCodeData = [
    {
      providerName: "INDIGO",
      providerCode: "6E-",
      providerType: "International"
    },
    { providerName: "SPICEJET", providerCode: "SG-", providerType: "Domestic" },
    {
      providerName: "AIR ASIA",
      providerCode: "I5-",
      providerType: "International"
    },
    { providerName: "AIR INDIA", providerCode: "SG-", providerType: "Domestic" }
  ];
  flightFormGroup: FormGroup;
  airlines: AirLine[];
  airline: AirLine;

  constructor(
    private dataservice: DataService,
    private formbuilder: FormBuilder,
    private router: Router
  ) {}
  getFlights() {
    this.dataservice.getFlights().subscribe(data => {
      this.airlines = data;
    });
  }
  ngOnInit() {
    this.flightFormGroup = new FormGroup({
      providerName: new FormControl("",[providerNameValidator]),
      providerCode: new FormControl(""),
      providerType: new FormControl("",[providerTypeValidator])
    });

    this.getFlights();
  }

  nametoUpdate = "";
  typetoUpdate = "";

  addFlight() {
    this.providerCodeData.forEach(element => {
      if (
        element.providerName == this.nametoUpdate &&
        element.providerType == this.typetoUpdate
      ) {
        this.dataservice
          .addFlight(this.flightFormGroup.value)
          .pipe()
          .subscribe(data => {
            this.airline = data;
           
          });
        this.isvalidDetails = true;
        this.getFlights();

        this.router.navigate(["/home"]);
      } else {
        this.isvalidDetails = false;
      }
    });
  }
}
