import { Component, OnInit } from "@angular/core";
import { DataService } from "../data.service";
import { AirLine } from "../airline-data";
import { Router } from "@angular/router";

@Component({
  selector: "app-view-flight",
  templateUrl: "./view-flight.component.html"
})
export class ViewFlightComponent implements OnInit {
  displayData: boolean;
  airline: AirLine;
  airLines: AirLine[];
  constructor(private dataservice: DataService, private router: Router) {}
  getFlights() {
    this.dataservice.getFlights().subscribe(data => {
      this.airLines = data;
    });
  }
  ngOnInit() {
    this.getFlights();
  }
}
