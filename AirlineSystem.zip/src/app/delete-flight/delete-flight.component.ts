import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators
} from "@angular/forms";
import { DataService } from '../data.service';
import { AirLine } from '../airline-data';
import { Router } from "@angular/router";
import {providerTypeValidator} from '../providertype';
import {providerCodeValidator} from '../providercode';

@Component({
  selector: 'app-delete-flight',
  templateUrl: './delete-flight.component.html'
})

export class DeleteFlightComponent implements OnInit {
  flightFormGroup: FormGroup;
  airlines: AirLine[];
isvalidDetails=true;
  displayData: boolean;


  constructor(private dataservice: DataService, private router:Router,private formbuilder:FormBuilder) { }

   ngOnInit() {
    this.flightFormGroup = new FormGroup({
       
      providerCode: new FormControl("",[providerCodeValidator]),
      providerType: new FormControl("",[providerTypeValidator])
    });

  }


 airlineId=0;

 codetoUpdate="";
 typetoUpdate="";
  deleteFlight() { this.airlines.forEach(element => {
        if (element.providerCode == this.codetoUpdate && element.providerType == this.typetoUpdate) {
          this.airlineId = element.id;
       
      console.log(this.airlineId);
    this.dataservice.deleteFlight(this.airlineId).subscribe(data => {
      this.isvalidDetails=true;
      this.router.navigate(['']);
     
    });
  }
   this.isvalidDetails=false;
      });
  }
 
}
