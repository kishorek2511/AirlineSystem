import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { InMemoryWebApiModule } from "angular-in-memory-web-api";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { UserData } from "./airline-data.service";

import { HomeComponent } from "./home/home.component";
import { ViewFlightComponent } from "./view-flight/view-flight.component";
import { ModifyFlightComponent } from "./modify-flight/modify-flight.component";

import { HttpClientModule } from "@angular/common/http";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CreateflightComponent } from "./create-flight/create-flight.component";
import { DeleteFlightComponent } from "./delete-flight/delete-flight.component";

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    ViewFlightComponent,
    CreateflightComponent,
    DeleteFlightComponent,
    ModifyFlightComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    InMemoryWebApiModule.forRoot(UserData),
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
