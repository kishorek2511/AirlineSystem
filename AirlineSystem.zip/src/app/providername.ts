import {AbstractControl} from '@angular/forms'
import { AirLine } from "./airline-data";

export function providerNameValidator(control: AbstractControl){

     if (control.value=='INDIGO'|| control.value=='SPICEJET'||control.value=='AIR ASIA' || control.value=='GO AIR'||control.value=='AIR INDIA') {
  return null;
}
else{
  return  {'name':true};
}
} 
